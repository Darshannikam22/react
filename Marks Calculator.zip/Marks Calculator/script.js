"use strict";

document.getElementById("btn").onclick = function () {
  var data1 = parseInt(document.getElementById("x1").value);
  var data2 = parseInt(document.getElementById("x2").value);
  var data3 = parseInt(document.getElementById("x3").value);

  var marks = "";
  var percent = "";
  var grade = "";

  marks = data1 + data2 + data3;
  percent = (marks / 300) * 100;
  if (percent < 60 && percent > 45) {
    grade = "C";
  } else if (percent < 80 && percent > 60) {
    grade = "B";
  } else if (percent < 90 && percent > 80) {
    grade = "A";
  } else if (percent <= 100 && percent > 90) {
    grade = "A+";
  } else {
    grade = "Fail !!!";
  }

  document.getElementById("y1").innerHTML = "Total Marks: " + marks;
  document.getElementById("y2").innerHTML =
    "Percentage: " + percent.toFixed(2) + "%";
  document.getElementById("y3").innerHTML = "Grade: " + grade;

  if (grade != "Fail !!!") {
    // chart script start
    Highcharts.chart("container", {
      chart: {
        type: "variablepie",
      },
      title: {
        text: "Subjects Marks",
        align: "left",
      },
      tooltip: {
        headerFormat: "",
        pointFormat:
          '<span style="color:{point.color}">\u25CF</span> <b> ' +
          "{point.name}</b><br/>" +
          "Marks: <b>{point.y}</b><br/>",
      },
      series: [
        {
          minPointSize: 10,
          innerSize: "20%",
          zMin: 0,
          name: "Marks",
          borderRadius: 5,
          data: [
            {
              name: "Physics",
              y: data1,
            },
            {
              name: "Chemistry",
              y: data2,
            },
            {
              name: "Mathematics",
              y: data3,
            },
          ],
          colors: [
            "#4caefe",
            "#3dc3e8",
            "#2dd9db",
            "#1feeaf",
            "#0ff3a0",
            "#00e887",
            "#23e274",
          ],
        },
      ],
    });
    // chart script end
  }
};
